$(document).ready(function(){
    $('.fa-spoon').click(function(){
        $(this).toggleClass('fa-times')
    });
});